Ah! So you've downloaded this! Since you're here, I'll tell you something. This here .ZIP has a .ips file to paste data over to a clean SMW ROM. I've edited things like Mario's hitbox and such so I can get ready to release a new player character, the Coin! The Coin is a small golden-like creature that lives in question (?) mark blocks. This Coin will appear in my hack, The Coin's Adventure! 
-----------------------------Attention:--------------------------------
This hack is NOT a demo to base off of your hack!
------------------------------------------------------------------------
� Copyright 2011-2012 Mini_Coin 
All rights reserved.
________________________________________________________________________Changelog:
V1.0-First demo release
V1.0.1-Added Small Mario balloon fix, altered OW, changed level 10F (which included a new Map16 block), changed EVERY message block dialouge, disabled cape flight, applied misc. hex edits.
V1.0.1.1-Misc. edits, New OW design!
________________________________________________________________________
